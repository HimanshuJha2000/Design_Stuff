//func (abc *A) method () {
//
//}

//["ADD A 2", "", ]

package model

import "errors"

type Register struct {
	Name  string
	Value int32
}

//func Init() {
//	registerMap = m
//}

var registerMap = make(map[string]Register)

func GetAllRegister() []Register {
	var registers []Register
	for _, register := range registerMap {
		registers = append(registers, register)
	}
	return registers
}

func UpdateRegister(register Register) error {
	if _, ok := registerMap[register.Name]; ok {
		registerMap[register.Name] = register
		return nil
	}
	err := errors.New("register not exist")
	return err
}

func Reset() {
	for registerName, _ := range registerMap {
		register := registerMap[registerName]
		register.Value = 0
		registerMap[registerName] = register
	}
}

func AddRegister(registerName string) {
	register := Register{
		Name:  registerName,
		Value: 0,
	}
	registerMap[registerName] = register
}

func GetRegister(registerName string) (Register, error) {
	if register, ok := registerMap[registerName]; ok {
		return register, nil
	}
	register := Register{}
	err := errors.New("register not exist")
	return register, err
}
