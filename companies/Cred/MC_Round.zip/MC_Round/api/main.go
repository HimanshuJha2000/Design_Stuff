package main

import (
	"fmt"
	"github.com/DevtronLabs/MC_Round/service/instructionHandling"
)

func main() {
	var instructions = []string{
		"INR A",
	}
	result, err := instructionHandling.Execute(instructions)
	fmt.Println(result, err)
}
