package instructionHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/enums"
	"github.com/DevtronLabs/MC_Round/model"
	"github.com/DevtronLabs/MC_Round/service/operationHandler"
	"strings"
)

func Execute(instructions []string) ([]model.Register, error) {
	var result []model.Register
	for i, _ := range instructions {

		instruction := strings.Split(instructions[i], " ")
		operatorType := enums.OperatorType(enums.OperatorType_value[instruction[0]])
		operatorHandler, err := operationHandler.GetOperatorInstance(operatorType)
		if err != nil {
			return result, errors.New("Invalid instruction sent by the user")
		}
		err = operatorHandler.ExecuteOperation(instruction)
		if err != nil {
			return nil, err
		}
	}
	result = model.GetAllRegister()
	return result, nil
}
