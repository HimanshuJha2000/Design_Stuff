package operationHandler

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/enums"
	"github.com/DevtronLabs/MC_Round/service/operatorHandling"
)

func GetOperatorInstance(operatorType enums.OperatorType) (operatorHandling.OperatorHandler, error) {
	switch operatorType {
	case enums.OperatorType_ADD:
		return operatorHandling.AddOperationObject, nil
	case enums.OperatorType_ADR:
		return operatorHandling.AdrOperationObject, nil
	case enums.OperatorType_MOV:
		return operatorHandling.MoveOperationObject, nil
	case enums.OperatorType_SET:
		return operatorHandling.SetOperationObject, nil
	case enums.OperatorType_INR:
		return operatorHandling.IncrementOperationObject, nil
	case enums.OperatorType_DCR:
		return operatorHandling.DecrementOperationObject, nil
	case enums.OperatorType_RST:
		return operatorHandling.ResetOperationObject, nil
	default:
		return nil, errors.New("Invalid Operator sent by the user")
	}

}
