package operatorHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/model"
)

func init() {
	DecrementOperationObject = &decrementOperation{}
}

type decrementOperation struct {
}

var DecrementOperationObject *decrementOperation

func (d decrementOperation) ExecuteOperation(instruction []string) error {
	register, err := model.GetRegister(instruction[1])
	if err != nil {
		model.AddRegister(instruction[1])
		register, _ = model.GetRegister(instruction[1])
	}
	register.Value = register.Value - 1
	err = model.UpdateRegister(register)
	if err != nil {
		err = errors.New("register decrement operation failed")
		return err
	}
	return nil
}
