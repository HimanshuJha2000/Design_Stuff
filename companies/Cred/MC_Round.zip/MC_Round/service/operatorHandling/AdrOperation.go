package operatorHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/model"
)

func init() {
	AdrOperationObject = &adrOperation{}
}

type adrOperation struct {
}

var AdrOperationObject *adrOperation

func (d adrOperation) ExecuteOperation(instruction []string) error {
	registerA, err := model.GetRegister(instruction[1])
	if err != nil {
		model.AddRegister(instruction[1])
		registerA, _ = model.GetRegister(instruction[1])
	}
	registerB, err := model.GetRegister(instruction[2])
	if err != nil {
		model.AddRegister(instruction[1])
		registerB, _ = model.GetRegister(instruction[2])
	}

	registerA.Value = registerA.Value + registerB.Value
	err = model.UpdateRegister(registerA)
	if err != nil {
		err = errors.New("register to register addtion operation failed")
		return err
	}
	return nil
}
