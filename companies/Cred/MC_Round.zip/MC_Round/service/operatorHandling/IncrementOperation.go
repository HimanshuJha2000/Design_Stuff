package operatorHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/model"
)

func init() {
	IncrementOperationObject = &incrementOperation{}
}

type incrementOperation struct {
}

var IncrementOperationObject *incrementOperation

func (d incrementOperation) ExecuteOperation(instruction []string) error {
	register, err := model.GetRegister(instruction[1])
	if err != nil {
		model.AddRegister(instruction[1])
		register, _ = model.GetRegister(instruction[1])
	}
	register.Value = register.Value + 1
	err = model.UpdateRegister(register)
	if err != nil {
		err = errors.New("register increment operation failed")
		return err
	}
	return nil
}
