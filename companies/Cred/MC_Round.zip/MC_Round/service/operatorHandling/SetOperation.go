package operatorHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/model"
	"github.com/spf13/cast"
)

func init() {
	SetOperationObject = &setOperation{}
}

type setOperation struct {
}

var SetOperationObject *setOperation

func (d setOperation) ExecuteOperation(instruction []string) error {
	register, err := model.GetRegister(instruction[1])
	if err != nil {
		model.AddRegister(instruction[1])
		register, _ = model.GetRegister(instruction[1])
	}
	register.Value = cast.ToInt32(instruction[2])
	err = model.UpdateRegister(register)
	if err != nil {
		err = errors.New("register set operation failed")
		return err
	}
	return nil
}
