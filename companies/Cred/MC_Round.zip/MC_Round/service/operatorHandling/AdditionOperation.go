package operatorHandling

import (
	"errors"
	"github.com/DevtronLabs/MC_Round/model"
	"github.com/DevtronLabs/MC_Round/validator"
	"github.com/spf13/cast"
)

func init() {
	AddOperationObject = &additionOperation{}
}

type additionOperation struct {
}

var AddOperationObject *additionOperation

// ins : "ADD" "A" "12"
func (d additionOperation) ExecuteOperation(instruction []string) error {
	valid := instructionValidation(instruction)
	if !valid {
		return errors.New("Not a valid register or operator")
	}
	register, err := model.GetRegister(instruction[1])
	if err != nil {
		model.AddRegister(instruction[1])
		register, _ = model.GetRegister(instruction[1])
	}
	register.Value = register.Value + cast.ToInt32(instruction[2])
	err = model.UpdateRegister(register)
	if err != nil {
		err = errors.New("register addition operation failed")
		return err
	}
	return nil
}

func instructionValidation(instruction []string) bool {
	valid := validator.ValidateOperator(instruction[0])
	valid = validator.ValidateRegister(instruction[1])
	return valid
}
