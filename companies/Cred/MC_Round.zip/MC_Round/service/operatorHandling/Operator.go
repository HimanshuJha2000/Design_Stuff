package operatorHandling

type OperatorHandler interface {
	ExecuteOperation(instruction []string) error
}
