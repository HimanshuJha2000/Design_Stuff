package operatorHandling

import "github.com/DevtronLabs/MC_Round/model"

func init() {
	ResetOperationObject = &resetOperation{}
}

type resetOperation struct {
}

var ResetOperationObject *resetOperation

func (d resetOperation) ExecuteOperation(instruction []string) error {
	model.Reset()
	return nil
}
