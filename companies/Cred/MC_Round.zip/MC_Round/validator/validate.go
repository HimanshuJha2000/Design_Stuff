package validator

import (
	enums2 "github.com/DevtronLabs/MC_Round/enums"
)

func ValidateOperator(operatorName string) bool {
	operatorType := enums2.OperatorType(enums2.OperatorType_value[operatorName])
	if operatorType == enums2.OperatorType_NO_TYPE {
		return false
	}
	return true
}

func ValidateRegister(registerName string) bool {
	registerType := enums2.RegisterType(enums2.RegisterTypeType_value[registerName])
	if registerType == enums2.RegisterTypeType_NO_TYPE {
		return false
	}
	return true
}
